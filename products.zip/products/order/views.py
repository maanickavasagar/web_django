# # views.py
from rest_framework import viewsets
from .models import Category, Product
# from .serializers import CategorySerializer, ProductSerializer

# class CategoryViewSet(viewsets.ModelViewSet):
#     queryset = Category.objects.all()
#     serializer_class = CategorySerializer

# class ProductViewSet(viewsets.ModelViewSet):
#     queryset = Product.objects.all()
#     serializer_class = ProductSerializer



# from rest_framework.decorators import api_view
# from rest_framework.response import Response
# from rest_framework import status
# from .models import Category
# from .serializers import CategorySerializer

# @api_view(['GET', 'POST'])
# def category(request):
#     if request.method == 'GET':
#         plans = Category.objects.all()
#         serializer = CategorySerializer(plans, many=True)
#         return Response(serializer.data)

#     elif request.method == 'POST':
#         serializer = CategorySerializer(data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             return Response(serializer.data, status=status.HTTP_201_CREATED)
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

#     return Response({'error': 'Method not allowed.'}, status=status.HTTP_405_METHOD_NOT_ALLOWED)


from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import Category
from .serializers import *
from .serializers import CategoryWithProductsSerializer


@api_view(['GET'])
def category_with_products(request):
    if request.method == 'GET':
        categories = Category.objects.prefetch_related('product').all()

        serializer = CategoryWithProductsSerializer(categories, many=True)
        return Response({'const_data': {'grandCount': '0', 'grandTotal': '0'}, 'data': serializer.data})


# @api_view(['GET'])
# def category_with_products(request):
#     if request.method == 'GET':
#         categories = Category.objects.prefetch_related('product_set').all()

#         serializer = CategoryWithProductsSerializer(categories, many=True)
        
#         # Serialize products for each category
#         categories_data = serializer.data
#         for category_data in categories_data:
#             category_products = category_data['products']
#             category_product_serializer = ProductSerializer(category_products, many=True)
#             category_data['products'] = category_product_serializer.data

#         data = {
#             'message': 'Categories with associated products',
#             'categories': categories_data,
#         }
#         return Response(data)


# @api_view(['GET'])
# def category_with_products(request):
#     if request.method == 'GET':
#         products = Product.objects.all()
#         categories = Category.objects.prefetch_related('product_set').all()
#         print(categories,"njejk")
#         serializer = CategoryWithProductsSerializer(categories, many=True)
#         print(serializer)
#         return Response(serializer.data)

# from rest_framework.views import APIView
# from rest_framework.response import Response
# from .models import Category
# from .serializers import CategoryWithProductsSerializer

# @api_view(['GET'])
# def ItemList(request):
#     if request.method == 'GET':
#         products = Product.objects.all()
#         categories = Category.objects.prefetch_related('category').all()
#         serializer = CategoryWithProductsSerializer(categories,products, many=True)
#         print(serializer)
#         return Response(serializer.data)

from django.core.mail import send_mail
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import Product
from .serializers import ProductSerializer

@api_view(['GET', 'POST'])
def product_list(request):
    if request.method == 'GET':
        products = Product.objects.all()
        serializer = ProductSerializer(products, many=True)
        return Response(serializer.data)


from django.core.mail import send_mail

from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import Product
from .serializers import ProductSerializer

# @api_view(['GET', 'POST'])
# def product_list(request):
#     if request.method == 'GET':
#         products = Product.objects.all()
#         serializer = ProductSerializer(products, many=True)
#         return Response(serializer.data)

#     elif request.method == 'POST':
#         # Define your filtering criteria here
#         # For example, if you want to filter products by title starting with 'SomeTitle'
#         filtered_products = Product.objects.all()
#         serializer = ProductSerializer(filtered_products, many=True)

#         # Optionally, you can check if there are any filtered products
#         if not filtered_products.exists():
#             return Response({'error': 'No products match the filtering criteria.'}, status=status.HTTP_404_NOT_FOUND)

#         # Send email notification
#         send_mail(
#             'New Product Created',
#             'A new product has been added.',
#             'from@example.com',  # Replace with your email address
#             ['to@example.com'],  # Replace with recipient email address(es)
#             fail_silently=False,
#         )

#         return Response({'data': serializer.data, 'order': 'Order created successfully'})
    
#     return Response({'error': 'Method not allowed.'}, status=status.HTTP_405_METHOD_NOT_ALLOWED)


from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import Customer
from .serializers import ProductSerializer
from .models import Product

# @api_view(['GET', 'POST'])
# def product_list(request):
#     if request.method == 'GET':
#         products = Product.objects.all()
#         serializer = ProductSerializer(products, many=True)
#         return Response(serializer.data)

#     elif request.method == 'POST':
#         # Retrieve data from the request
#         product_data = request.data.get('details')
#         product_id = product_data.get('product_id')
        
#         # Retrieve Product instance corresponding to product_id
#         try:
#             product_instance = Product.objects.get(pk=product_id)
#         except Product.DoesNotExist:
#             return Response({'error': 'Product not found'}, status=status.HTTP_404_NOT_FOUND)
        
#         name = request.data.get('name')
#         email = request.data.get('email')
#         address = request.data.get('address')
#         land_mark = request.data.get('land_mark')
#         phone = request.data.get('phone')
#         title = product_data.get('title')
#         original_price = product_data.get('original_price')
#         selling_price = product_data.get('selling_price')
#         description = product_data.get('description')
#         quantity = product_data.get('quantity')
#         total_price = product_data.get('total_price')
#         payment = request.data.get('payment')

#         # Create Customer instance
#         customer = Customer.objects.create(
#             product_id=product_instance,  # Assign Product instance, not product_id
#             name=name,
#             email=email,
#             address=address,
#             land_mark=land_mark,
#             phone=phone,
#             payment=payment
#         )

#         # No need to create associated product separately
        
#         # Associate the product with the customer (Optional, based on your model logic)
#         # customer.details.add(product_instance)

#         # Send email notification
#         send_mail(
#             'New Product Created',
#             f'A new product has been added: {title}',
#             'from@example.com',  # Replace with your email address
#             ['to@example.com'],  # Replace with recipient email address(es)
#             fail_silently=False,
#         )

#         return Response({'message': 'Order created successfully'}, status=status.HTTP_201_CREATED)

#     return Response({'error': 'Method not allowed.'}, status=status.HTTP_405_METHOD_NOT_ALLOWED)


# from rest_framework import status
# from rest_framework.decorators import api_view
# from rest_framework.response import Response
# from .models import Customer
# from .serializers import ProductSerializer
# from .models import Product

# @api_view(['GET', 'POST'])
# def product_list(request):
#     if request.method == 'GET':
#         products = Product.objects.all()
#         serializer = ProductSerializer(products, many=True)
#         return Response(serializer.data)

#     elif request.method == 'POST':
#         # Retrieve data from the request
#         product_data = request.data.get('details')
        
#         # Store all product details in the 'details' field
#         details = {
#             "title": product_data.get('title'),
#             "product_image": product_data.get('product_image'),
#             "original_price": product_data.get('original_price'),
#             "selling_price": product_data.get('selling_price'),
#             "description": product_data.get('description'),
#             "quantity": product_data.get('quantity'),
#             "total_price": product_data.get('total_price')
#         }

#         # Create Customer instance with all product details stored in 'details' field
#         customer = Customer.objects.create(
#             details=details,
#             name=request.data.get('name'),
#             email=request.data.get('email'),
#             address=request.data.get('address'),
#             land_mark=request.data.get('land_mark'),
#             phone=request.data.get('phone'),
#             payment=request.data.get('payment')
#         )
#         print(customer)

#         # Send email notification with product details
#         html_message = render_to_string('email_template.html', {
#                 'name': request.data.get('name'),
#                 'phone': request.data.get('phone'),
#                 'address': request.data.get('address'),
#                 'title': details['title'],
#                 'total_price': details['total_price'],
#             })

#             # Remove HTML tags from the message for plaintext email
#             plain_message = strip_tags(html_message)

#             # Send email notification with product details
#             send_mail(
#                 'New Product Order',
#                 plain_message,
#                 'from@example.com',  # Replace with your email address
#                 [request.data.get('email')],  # Replace with recipient email address(es)
#                 html_message=html_message,  # Attach HTML content
#                 fail_silently=False,
#             )

#         return Response({'message': 'Order created successfully'}, status=status.HTTP_201_CREATED)

#     return Response({'error': 'Method not allowed.'}, status=status.HTTP_405_METHOD_NOT_ALLOWED)
from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.utils.html import strip_tags
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import Customer
from .serializers import ProductSerializer
from .models import Product

@api_view(['GET', 'POST'])
def product_list(request):
    if request.method == 'GET':
        products = Product.objects.all()
        serializer = ProductSerializer(products, many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        # Retrieve data from the request
        product_data = request.data.get('details')
        
        # Store all product details in the 'details' field
        details = {
            "title": product_data.get('title'),
            "product_image": product_data.get('product_image'),
            "original_price": product_data.get('original_price'),
            "selling_price": product_data.get('selling_price'),
            "description": product_data.get('description'),
            "quantity": product_data.get('quantity'),
            "total_price": product_data.get('total_price')
        }

        # Create Customer instance with all product details stored in 'details' field
        customer = Customer.objects.create(
            details=details,
            name=request.data.get('name'),
            email=request.data.get('email'),
            address=request.data.get('address'),
            land_mark=request.data.get('land_mark'),
            phone=request.data.get('phone'),
            payment=request.data.get('payment')
        )

        # Render HTML template for email message
        html_message = render_to_string('email_template.html', {
            'name': request.data.get('name'),
            'phone': request.data.get('phone'),
            'address': request.data.get('address'),
            'title': details['title'],
            'quantity':details['quantity'],
            'total_price': details['total_price'],
        })

        # Remove HTML tags from the message for plaintext email
        plain_message = strip_tags(html_message)

        # Send email notification with product details
        send_mail(
            'New Product Order',
            plain_message,
            'from@example.com',  # Replace with your email address
            [request.data.get('email')],  # Replace with recipient email address(es)
            html_message=html_message,  # Attach HTML content
            fail_silently=False,
        )

        return Response({'message': 'Order created successfully'}, status=status.HTTP_201_CREATED)

    return Response({'error': 'Method not allowed.'}, status=status.HTTP_405_METHOD_NOT_ALLOWED)
