from django.db import models
from django.contrib.auth.models import User
# from django.http import status
from rest_framework import status


class Category(models.Model):
    category = models.CharField(max_length=255,blank=True,null=True)
    image = models.ImageField(upload_to='category/', null=True, blank=True)
    original_price = models.DecimalField(max_digits=10, decimal_places=2)
    selling_price = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.TextField(null=True,blank=True)
    quantity = models.PositiveIntegerField(default=0)
    total_price = models.CharField(max_length=255,blank=True,null=True)



    def __str__(self) -> str:
        return self.category
        
class Product(models.Model):
    product = models.ForeignKey(Category, on_delete=models.CASCADE,null=True,blank=True,related_name='product')
    title = models.CharField(max_length=255)
    product_image = models.ImageField(upload_to='products/', null=True, blank=True)
    quantity = models.PositiveIntegerField(default=0)
    original_price = models.DecimalField(max_digits=10, decimal_places=2)
    selling_price = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.TextField()
    total_price = models.CharField(max_length=255,blank=True,null=True)



    def __str__(self) -> str:
        return self.title

from django.db import models
from .models import Product

class Customer(models.Model):
    product_id = models.ForeignKey(Product, on_delete=models.CASCADE, null=True, blank=True, related_name='details')
    name = models.CharField(max_length=255, blank=True, null=True)
    email = models.CharField(max_length=255, blank=True, null=True)
    address = models.TextField()
    phone = models.CharField(max_length=255, blank=True, null=True)
    land_mark = models.CharField(max_length=255, blank=True, null=True)
    details = models.JSONField(default=dict)  # Using django.db.models.JSONField
    payment = models.CharField(max_length=255, blank=True, null=True)


