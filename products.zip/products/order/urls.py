import statistics
from django.conf import Settings, SettingsReference, settings
from django.contrib import admin
from django.urls import path,include
from .models import *
from .views import *
from order import views
from django.urls import path
from .import views
from django.conf import settings
from django.conf.urls.static import static 
from django.urls import path, include
from rest_framework.routers import DefaultRouter
# from .views import CategoryViewSet, ProductViewSet
# from .views import CategoryWithProductsView



urlpatterns = [
#     path('categories/', CategoryListCreateView.as_view(), name='category-list-create'),
    # path('category/',category, name='plan_list'),
    path('item/',category_with_products, name='category-with-products'),

    path('order/',product_list, name='plan_list'),

    # path('categories/', CategoryWithProductsView.as_view(), name='category-list-with-products'),



]
