from django.contrib import admin
from .models import *
from . import models
from import_export.admin import ImportExportModelAdmin, ExportActionMixin, ImportMixin
from django.contrib.auth.models import User
from import_export import resources




@admin.register(Category)
class CategoryAdmin(ImportExportModelAdmin, admin.ModelAdmin):
    list_display = ['id', 'category', 'image', 'original_price', 'selling_price', 'description', 'quantity','total_price']

@admin.register(Product)
class ProductAdmin(ImportExportModelAdmin, admin.ModelAdmin):
    list_display=['product','title','product_image','original_price','selling_price','description','quantity','total_price']

@admin.register(Customer)
class CustomerAdmin(ImportExportModelAdmin, admin.ModelAdmin):
    list_display=['product_id','name','email','address','land_mark','phone','details','payment']
