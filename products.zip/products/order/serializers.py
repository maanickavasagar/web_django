from rest_framework import serializers
from .models import *


# class CategorySerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Category
#         fields = ['name','image','original_price','selling_price','description']

# class ProductSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Product
#         fields = ['product','name','product_image','original_price','selling_price','description','quantity']



# class ProductSerializer(serializers.ModelSerializer):
#     category = CategorySerializer()

#     class Meta:
#         model = Product
#         fields = ['product','name', 'product_image', 'original_price', 'selling_price', 'description', 'quantity','category']

# class ProductSerializer(serializers.ModelSerializer):
#     category_field = CategorySerializer(source='category', read_only=True)

#     class Meta:
#         model = Product
#         fields = ['name', 'product_image', 'original_price', 'selling_price', 'description', 'quantity', 'category_field']


# class CategoryWithProductsSerializer(serializers.ModelSerializer):
#     products = ProductSerializer(many=True, read_only=True)

#     class Meta:
#         model = Category
#         fields = ['name', 'image', 'original_price', 'selling_price', 'description', 'products']

# from rest_framework import serializers
# from .models import Category, Product

# class ProductSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Product
#         fields = ['name', 'product_image', 'original_price', 'selling_price', 'description', 'quantity']

# class CategoryWithProductsSerializer(serializers.ModelSerializer):
#     products = ProductSerializer(many=True, read_only=True)

#     class Meta:
#         model = Category
#         fields = ['name', 'image', 'products']

from rest_framework import serializers
from .models import Category, Product

class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ['id','title', 'product_image', 'original_price', 'selling_price', 'description', 'quantity','total_price']

class CategoryWithProductsSerializer(serializers.ModelSerializer):
    product = ProductSerializer(many=True, read_only=True)

    class Meta:
        model = Category
        fields = ['id','category', 'image', 'original_price', 'selling_price', 'description','quantity','total_price','product']


class CustomerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Customer
        fields = '__all__'

